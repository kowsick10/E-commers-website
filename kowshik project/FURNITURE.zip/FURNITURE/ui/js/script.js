'use strict';

/**
 * add event on element
 */