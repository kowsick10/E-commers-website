function validate(){
    var username=document.getElementById("username").value;
    var username=document.getElementById("password").value;
    if(isdigit(x)||x<1||x>100)
    {
        text="login successful";
        <a href="page3.html"></a>
       

    }
    else if(isNaN(x)||x<1||x>10){
        text="login failed";
    }
}